#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <iostream>
using namespace std;
int main(){
	int i;
	clock_t tInicio, tFim, tDecorrido;
	tInicio = clock();
	for(i=0; i<100000000 ; i++){
	}
	tFim = clock();
	tDecorrido = ((tFim - tInicio)*1000 / CLOCKS_PER_SEC);
	cout<<tDecorrido;
	return 0;
}
